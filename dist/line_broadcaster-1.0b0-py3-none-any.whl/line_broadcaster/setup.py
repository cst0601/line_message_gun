import os
import setuptools

setuptools.setup(
    name='line_broadcaster',
    version='1.0_b',
    keywords='demo',
    description='A demo for python packaging.',
    long_description="nah",
    author='ST Chien',
    author_email='greg870601@gmail.com',

    url='',
    packages=setuptools.find_packages(),
    license='MIT'
)
